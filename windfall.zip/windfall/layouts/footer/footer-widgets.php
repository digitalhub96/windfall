<!-- Footer Widgets -->
<?php 
$windfall_id    = ( isset( $post ) ) ? $post->ID : 0;
$windfall_id    = ( is_home() ) ? get_option( 'page_for_posts' ) : $windfall_id;
$windfall_id    = ( windfall_is_woocommerce_shop() ) ? wc_get_page_id( 'shop' ) : $windfall_id;
$windfall_meta  = get_post_meta( $windfall_id, 'page_type_metabox', true );
?>
<div class="row">
	<?php echo windfall_vt_footer_widgets(); ?>
</div>
<!-- Footer Widgets -->
<?php
